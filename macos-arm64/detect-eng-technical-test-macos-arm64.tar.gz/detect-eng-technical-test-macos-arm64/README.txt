detect-eng Technical Test
=========================

Full instructions: see CANDIDATE.md

Quick start (read scenarios):
  ./detect-eng-technical-test start

Candidate workflow:
  1. Read scenarios and create your deliverables:
     ./detect-eng-technical-test start --part 1   # Detection Engineering
     ./detect-eng-technical-test start --part 2   # Data Pipeline
     ./detect-eng-technical-test start --part 3   # Threat Intelligence

     Place files in:
       rules/                  Sigma/SA YAML detection rules
       parsing/vector.yaml     Vector log pipeline config
       threat-intel/           STIX2 JSON threat intel bundle

  2. (Optional) Start Docker stack to test against live data:
     cp .env.example .env
     docker compose up -d
     ./detect-eng-technical-test reset-stack --yes

  3. Upload your deliverables and replay datasets:
     ./detect-eng-technical-test rule-upload --all --replace
     ./detect-eng-technical-test threat-intel --setup-sa
     ./detect-eng-technical-test replay

     Then open http://localhost:5601 — Security Analytics > Findings

TUI:
  ./detect-eng-technical-test tui

No Python installation required.

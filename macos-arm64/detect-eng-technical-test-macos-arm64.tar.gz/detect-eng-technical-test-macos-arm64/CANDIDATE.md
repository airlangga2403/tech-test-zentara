# Detection Engineering — Technical Test Candidate Guide

A take-home assessment covering detection rule writing, log pipeline design, and threat
intelligence formatting. Three independent parts, completable in any order.

---

## Quick Start

```bash
# 1. Extract the distribution archive
tar xzf detect-eng-technical-test-linux-x64.tar.gz
cd detect-eng-technical-test-linux-x64

# 2. Copy environment file (edit password if desired)
cp .env.example .env

# 3. Read all scenario parts
./detect-eng-technical-test start
```

---

## Folder Layout

```
.
├── detect-eng-technical-test   # Standalone binary (no Python needed)
├── docker-compose.yml          # OpenSearch + Vector stack
├── .env.example                # Environment template
├── README.txt                  # Quick reference card
├── CANDIDATE.md                # This file
│
├── attack_data/                # [READ-ONLY] Provided datasets
│   └── datasets/
│       ├── attack_techniques/
│       │   ├── T1189/splunk/   # Splunk Web exploit logs
│       │   └── T1505.004/      # IIS backdoor logs
│       └── honeypot/           # T-Pot honeypot telemetry
│
├── rules/                      # [YOUR DELIVERABLE] Place Sigma/SA YAML rules here
├── parsing/                    # [YOUR DELIVERABLE] Place vector.yaml here
│   └── vector.yaml             # Starter template provided
├── threat-intel/               # [YOUR DELIVERABLE] Place stix2_iocs.json here
└── index-templates/            # [PROVIDED] OpenSearch index templates
    ├── logs-attack.json
    └── logs-honeypot.json
```

---

## Command Reference

### `start` — Read scenario parts

Display scenario descriptions for each part of the test.

```bash
./detect-eng-technical-test start              # All parts
./detect-eng-technical-test start --part 1     # Part 1 only
./detect-eng-technical-test start --part 2     # Part 2 only
./detect-eng-technical-test start --part 3     # Part 3 only
```

### `reset-stack` — Reset Docker stack

Tear down and recreate the OpenSearch + Vector Docker environment. Applies index
templates and creates target indices.

```bash
./detect-eng-technical-test reset-stack --yes
```

| Flag | Purpose |
|------|---------|
| `--yes` | Skip confirmation prompt |
| `--with-sa` | After reset, upload all rules and create a detector |
| `--with-ti` | After reset, run mock threat-intel setup |

### `replay` — Replay datasets into OpenSearch

Sends attack and honeypot datasets through Vector's Splunk HEC endpoint into
OpenSearch indices.

```bash
./detect-eng-technical-test replay                          # All datasets
./detect-eng-technical-test replay --datasets T1189/splunk  # Specific dataset
./detect-eng-technical-test replay --no-honeypot            # Skip honeypot
```

### `rule-upload` — Upload rules to Security Analytics

Uploads Sigma YAML rules from `rules/` to the OpenSearch Security Analytics plugin
and optionally creates a detector.

```bash
./detect-eng-technical-test rule-upload --all                        # All rules + detector
./detect-eng-technical-test rule-upload --all --replace              # Replace existing detector
./detect-eng-technical-test rule-upload --all --no-detector          # Rules only, no detector
./detect-eng-technical-test rule-upload --all --index logs-attack    # Custom target index
```

| Flag | Default | Purpose |
|------|---------|---------|
| `--all` | off | Upload every `.yaml`/`.yml` in `rules/` |
| `--index` | `logs-attack` | Target index for detector creation |
| `--detector-name` | `rules_monitor` | Name for the created detector |
| `--replace` | off | Delete existing detectors first |
| `--no-detector` | off | Skip detector creation entirely |

### `threat-intel` — Validate and upload STIX bundle

Validates `threat-intel/stix2_iocs.json` and optionally uploads the IOCs to OpenSearch
Security Analytics threat intel.

```bash
./detect-eng-technical-test threat-intel                 # Validate STIX bundle
./detect-eng-technical-test threat-intel --setup-sa      # Validate + upload to SA
```

| Flag | Purpose |
|------|---------|
| `--setup-sa` | Upload validated IOCs to Security Analytics TI store |

### `tui` — Full-screen terminal UI

Launch the interactive Textual TUI for browsing scenarios and checking status.

```bash
./detect-eng-technical-test tui
```

---

## Parts Overview

| Part | Topic | Folder | Deliverable |
|------|-------|--------|-------------|
| 1 | Detection Engineering | `rules/` | Two Sigma YAML rules |
| 2 | Data Pipeline | `parsing/` | `vector.yaml` |
| 3 | Threat Intelligence | `threat-intel/` | `stix2_iocs.json` |

---

## Part 1 — Detection Engineering (Sigma YAML)

### Background

Two attack datasets have been replayed into OpenSearch via Vector's Splunk HEC source
and are stored in the `logs-attack` index. Each dataset contains raw log lines stored
in the `message` field.

#### Dataset 1 — T1189: Drive-by Compromise (Splunk Web Exploits)

Path: `attack_data/datasets/attack_techniques/T1189/splunk/`

#### Dataset 2 — T1505.004: IIS Component Backdoor

Path: `attack_data/datasets/attack_techniques/T1505.004/`

### Task

Write **two Sigma detection rules** targeting the replayed attack datasets.
Examine the log files under each dataset path to identify suitable detection indicators.

#### Rule 1 — Splunk Web Exploit Activity (T1189: Drive-by Compromise)

Write a Sigma rule that detects exploit activity from the T1189 Splunk Web dataset.
The rule must fire on at least one indicator discovered by inspecting the dataset.

#### Rule 2 — IIS Module Abuse and Logging Tampering (T1505.004: IIS Backdoor)

Write a Sigma rule that detects backdoor or tampering activity from the T1505.004 dataset.
The rule must fire on at least one indicator discovered by inspecting the dataset.

### Requirements

Use the **OpenSearch Security Analytics** Sigma format. Each rule must include:

| Field | Requirement |
|-------|-------------|
| `title` | Descriptive name |
| `logsource` | T1189: `product: web`, T1505.004: `product: windows` |
| `rules` | Named selections + `condition` |
| `level` | `high` |
| `tags` | ATT&CK technique tag (`attack.t1189` / `attack.t1505.004`) |
| `falsepositives` | At least one entry |

### Deliverable

Two YAML files in `rules/`:

- `rules/t1189_splunk_web_exploit.yaml`
- `rules/t1505_004_iis_module_abuse.yaml`

---

## Part 2 — Data Pipeline (Vector Config)

### Background

The detection engineering harness uses **Vector** (vector.dev) as its log pipeline.
Events arrive via a Splunk HEC endpoint and are routed to OpenSearch.

There are two logical streams:

| Stream | Source | Destination Index |
|--------|--------|-------------------|
| Attack datasets | replay tools | `logs-attack` |
| Honeypot telemetry | T-Pot sensors | `logs-honeypot` |

Honeypot events are JSON objects with metadata fields. Attack dataset logs may arrive as
raw strings or pre-parsed JSON.

### Task

Write a `vector.yaml` that:

1. Accepts logs via a **Splunk HEC source** on port `8088` (token from env var `VECTOR_HEC_TOKEN`)
2. Routes honeypot events to `logs-honeypot` in OpenSearch
3. Routes all other (attack dataset) logs to `logs-attack` in OpenSearch
4. Enriches honeypot events with an appropriate ATT&CK technique identifier based on the event content

Both sinks should connect to `http://opensearch:9200`.

### Requirements

| Section | Key requirements |
|---------|-----------------|
| `sources` | One Splunk HEC source, port 8088, token from env var `VECTOR_HEC_TOKEN` |
| `transforms` | One route transform to split streams + two remap transforms (one per stream) |
| `sinks` | Two Elasticsearch sinks — `logs-attack` and `logs-honeypot` |
| Transport | Both sinks connect to `http://opensearch:9200` |
| Honeypot enrich | Honeypot events must be parsed as JSON and enriched with a technique identifier |
| Attack normalise | Attack events should attempt JSON parsing with graceful fallback |

### Deliverable

A single file: `parsing/vector.yaml`

A starter template is provided in `parsing/vector.yaml` within the distribution.

---

## Part 3 — Threat Intelligence (STIX2 JSON)

### Context

Honeypot telemetry collected from T-Pot sensors needs to be correlated with public threat
intelligence feeds. Produce structured threat intelligence indicators from the data.

### Task

Create a **STIX 2.1** JSON bundle with `indicator` objects for the source IPs found in the
honeypot dataset. Analyze the honeypot data to identify which IPs have been observed
and would be relevant for threat intelligence purposes.

### STIX Bundle Requirements

Each indicator object must include:

| Field | Requirement |
|-------|-------------|
| `type` | `"indicator"` |
| `spec_version` | `"2.1"` |
| `id` | Valid STIX2 UUID (`indicator--<uuid4>`) |
| `created` / `modified` | ISO 8601 timestamps |
| `name` | Descriptive name including the IP |
| `indicator_types` | `["malicious-activity"]` |
| `pattern_type` | `"stix"` |
| `pattern` | `[ipv4-addr:value = '<ip>']` |
| `valid_from` | When the indicator became valid |
| `valid_until` | Expiry (90 days from first seen is acceptable) |
| `labels` | Include feed source (e.g. `"misp"`) |

The bundle itself must have:
- `"type": "bundle"`
- `"spec_version": "2.1"`
- All indicator objects in the `"objects"` array

### Deliverable

A single file: `threat-intel/stix2_iocs.json`

---

## Docker Runtime Workflow (Optional)

If you want to see your detections fire against live data, use the full Docker stack:

### Prerequisites

- Docker and Docker Compose installed
- At least 6 GB RAM available for OpenSearch

### Step-by-step

> Detectors and TI monitors must be in place **before** replay so that findings
> generate as data arrives in real-time.

```bash
# 1. Configure environment
cp .env.example .env

# 2. Start the stack (OpenSearch + Dashboards + Vector)
docker compose up -d

# 3. Wait for all services to be healthy (~30s)
docker compose ps

# 4. Reset stack, apply index templates, create fresh indices
./detect-eng-technical-test reset-stack --yes

# 5. Upload your detection rules and create a Security Analytics detector
./detect-eng-technical-test rule-upload --all --replace

# 6. Validate and upload your STIX threat-intel bundle to SA
./detect-eng-technical-test threat-intel --setup-sa

# 7. Replay attack and honeypot datasets through Vector
./detect-eng-technical-test replay
```

### View Results

- **OpenSearch Dashboards:** http://localhost:5601
- **Security Analytics → Findings:** Shows alerts triggered by your rules
- **Threat Intel:** IOC matches from your STIX indicators
- **Dev Tools:** Query indices directly via the console

### Stack Endpoints

| Service | URL |
|---------|-----|
| OpenSearch REST API | http://localhost:9201 |
| OpenSearch Dashboards | http://localhost:5601 |
| Vector HEC | http://localhost:8088 |
| Vector Health | http://localhost:8686/health |

Credentials are in `.env` (default: `admin` / `MyStrongPassword123!`).

---

## Verification Checklist

Before submitting your work, confirm:

- [ ] Part 1: Two YAML files in `rules/` with correct Sigma format
- [ ] Part 2: `parsing/vector.yaml` with HEC source, transforms, and sinks
- [ ] Part 3: `threat-intel/stix2_iocs.json` with valid STIX 2.1 bundle

If using the Docker runtime additionally verify:

- [ ] `logs-attack` index has documents
- [ ] `logs-honeypot` index has documents
- [ ] Security Analytics findings exist for your rules
- [ ] TI findings exist for your indicators

---

## Submission

Zip the entire distribution folder (including your deliverables) and submit:

```bash
cd ..
tar czf my-submission.tar.gz detect-eng-technical-test-linux-x64/
```
